﻿namespace HotelReservation.Models
{
    public class AvailabilityChecking
    {
        public int H_id { get; set; }
        public int RoomNumber { get; set; }
        public DateTime CheckInDate { get; set; }
    }
}
