﻿namespace HotelReservation.Models.DTO
{
    public class IdDTO
    {
        public int ID { get; set; }
    }
}
