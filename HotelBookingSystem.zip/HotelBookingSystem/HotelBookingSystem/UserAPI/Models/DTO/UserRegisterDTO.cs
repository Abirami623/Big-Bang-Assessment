﻿namespace UserAPI.Models.DTO
{
    public class UserRegisterDTO:User
    {
        public string UserPassword { get; set; }
    }
}
