﻿namespace HotelAPI.Models
{
    public class HotelAndRooms
    {
        public int HotelId { get; set; }
        public int RoomsCount { get; set; }
    }
}
