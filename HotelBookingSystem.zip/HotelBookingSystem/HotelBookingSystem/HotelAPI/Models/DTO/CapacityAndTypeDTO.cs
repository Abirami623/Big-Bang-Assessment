﻿namespace HotelAPI.Models.DTO
{
    public class CapacityAndTypeDTO
    {
        public int H_id { get; set; }
        public int? Capacity { get; set; }
        public string? Type { get; set; }
    }
}
