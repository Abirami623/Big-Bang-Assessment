﻿namespace HotelAPI.Models.DTO
{
    public class IdDTO
    {
        public int ID { get; set; }
    }
}
