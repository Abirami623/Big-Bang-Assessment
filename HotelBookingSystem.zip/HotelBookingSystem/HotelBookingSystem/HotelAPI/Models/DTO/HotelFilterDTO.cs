﻿namespace HotelAPI.Models.DTO
{
    public class HotelFilterDTO
    {
        public string? city { get; set; }
        public string? country { get; set; }
        public string? Amenities { get; set; }
    }
}
