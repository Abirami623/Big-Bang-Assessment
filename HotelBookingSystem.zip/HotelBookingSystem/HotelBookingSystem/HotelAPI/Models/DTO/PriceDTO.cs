﻿namespace HotelAPI.Models.DTO
{
    public class PriceDTO
    {
        public int H_Id { get; set; }
        public double MinValue { get; set; }
        public double MazValue { get; set; }
    }
}
